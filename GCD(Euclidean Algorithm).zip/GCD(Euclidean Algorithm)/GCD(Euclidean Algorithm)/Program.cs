﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GCD_Euclidean_Algorithm_
{
    class Program
    {

       /* The Euclidean Algorithm - Take two inputs from command prompt and output their GCD.*/
        static void Main(string[] args)

        {
            Console.Write("Enter 1st number to find GCD: ");
            int number1 = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter 2nd number to find GCD: ");
            int number2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("GCD of two numbers " + number1 + " and " + number2 + " is: " + CalGCD(number1, number2));

        }
        
        public static int CalGCD(int number1, int number2)
        {
            if (number2 == 0)
            {
                return number1;
            }

            return CalGCD(number2, number1 % number2);
        }


    }
    }

