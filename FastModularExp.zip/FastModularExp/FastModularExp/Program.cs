﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FastModularExp
{

    /*Fast Modular Exponentiation - Take three integer inputs B,K, and M of the form B^K(mod M) and return the answer B^K(mod M)*/
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Base Value (B): ");
            long B = Convert.ToInt32(Console.ReadLine());

            Console.Write("\nEnter Exponent (K): ");
            long K = Convert.ToInt32(Console.ReadLine());

            Console.Write("\nEnter Modular (M): ");
            long M = Convert.ToInt32(Console.ReadLine());
                        
            Console.WriteLine("\nB^K(mod M): {0}", BpowKmodM(B,K,M) );

        }
        
        // Calculate (b^k) % m 
        public static long BpowKmodM(long b, long k, long m)
        {
            long ans = BPowK(b, k); //Function to calculate power of any number (b^k)
            long mul = ans % m;

            return mul;
        }

        // Calculate (b^k)
        public static long BPowK(long b, long k)
        {
            if (k == 0)
                return 1;
            else
                return b * BPowK(b, k - 1);
        }



    }
}
